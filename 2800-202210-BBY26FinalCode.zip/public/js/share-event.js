"use strict"
async function loadSharePage(){
    await $('#share-plaveholder').load('/share-page');
}
loadSharePage();

